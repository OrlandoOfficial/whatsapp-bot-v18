/**
 * Main Launcher WhatsApp Bot
 * Created by Deni Orlando - https://orlando-digital.my.id
 */

const { exec } = require('child_process');

console.log('🚀 Menjalankan Bot WhatsApp...');
exec('node index.js', (err, stdout, stderr) => {
  if (err) {
    console.error(`❌ Terjadi kesalahan: ${err.message}`);
    return;
  }
  if (stderr) {
    console.error(`⚠️ STDERR: ${stderr}`);
    return;
  }
  console.log(`📩 STDOUT: ${stdout}`);
});
