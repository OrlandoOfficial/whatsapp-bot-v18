# 📦 Changelog

## v18.20.8
- Update versi Node.js ke 18.20.8
- Penambahan notifikasi pairing sukses
- Multi QR uploader
- Notifikasi ke admin saat bot aktif & gagal
- Sistem premium 7 hari otomatis
- Form pembelian premium + konfirmasi
- Limit pengguna gratis (3) dan premium (100)
- Panel PM2, Dockerfile, ecosystem, Procfile, dan Vercel support

