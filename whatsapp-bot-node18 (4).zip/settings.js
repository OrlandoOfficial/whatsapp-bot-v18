module.exports = {
  autoReadStatus: true,
  autoReactStatus: true,
  showTypingVoiceNote: true,
  enableWebsiteButton: true,
  enablePremiumMenu: true,
  enableSewaBot: true,
  pingIntervalSeconds: 60
};
