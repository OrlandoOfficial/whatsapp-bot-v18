module.exports = {
  ownerNumber: '6283106346274',
  instagram: 'https://instagram.com/d_orlando1',
  website: 'https://orlando-digital.my.id',
  image: 'https://orlando-digital.my.id/assets/logo.png',
  prefix: '#',
  creator: {
    name: 'Deni Orlando',
    instagram: 'https://instagram.com/d_orlando1',
    whatsapp: 'https://wa.me/6283106346274'
  },
  copyright:
    '© 2025 Bot by Deni Orlando - https://orlando-digital.my.id'
};
