module.exports = {
  apps: [
    {
      name: 'whatsapp-bot',
      script: './index.js',
      watch: true,
      ignore_watch: ['node_modules', 'auth', 'assets/qr-code.png'],
      env: {
        NODE_ENV: 'production'
      }
    },
    {
      name: 'bot-server',
      script: './server.js',
      watch: false,
      env: {
        PORT: 3000
      }
    }
  ]
};
