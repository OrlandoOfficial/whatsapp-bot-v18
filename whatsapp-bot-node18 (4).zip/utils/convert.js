// Module ini dapat dikembangkan untuk convert media, base64, buffer, dll

exports.toBase64 = (buffer) => buffer.toString('base64');

exports.fromBase64 = (base64) => Buffer.from(base64, 'base64');
