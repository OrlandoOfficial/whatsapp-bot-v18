module.exports = {
  axios: require('axios'),
  fs: require('fs'),
  path: require('path'),
  chalk: require('chalk'),
  moment: require('moment'),
  fetch: (...args) => import('node-fetch').then(({default: fetch}) => fetch(...args))
};
