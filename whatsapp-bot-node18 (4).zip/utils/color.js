const chalk = require('chalk');

module.exports = {
  info: (text) => console.log(chalk.blue('[INFO]'), text),
  success: (text) => console.log(chalk.green('[SUCCESS]'), text),
  warning: (text) => console.log(chalk.yellow('[WARNING]'), text),
  error: (text) => console.log(chalk.red('[ERROR]'), text)
};
