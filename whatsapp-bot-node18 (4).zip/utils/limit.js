const fs = require('fs');
const dbPath = './auth/user-db.json';

if (!fs.existsSync(dbPath)) {
  fs.writeFileSync(dbPath, JSON.stringify({ banned: [], premium: [], usage: {}, requests: [], premium_expire: {} }, null, 2));
}

const db = JSON.parse(fs.readFileSync(dbPath));
function saveDB() {
  fs.writeFileSync(dbPath, JSON.stringify(db, null, 2));
}

function checkLimit(user, isPremium) {
  const maxLimit = isPremium ? 100 : 3;
  if (!db.usage[user]) db.usage[user] = 0;
  if (db.usage[user] >= maxLimit) return false;

  db.usage[user] += 1;
  saveDB();
  return true;
}

// Hapus premium yang expired
function cleanupExpiredPremium(sock) {
  const now = Date.now();
  for (let user in db.premium_expire) {
    if (now > db.premium_expire[user]) {
      db.premium = db.premium.filter(u => u !== user);
      delete db.premium_expire[user];
      sock.sendMessage(user, { text: '⚠️ Masa aktif Premium kamu telah berakhir. Silakan beli ulang untuk menikmati fitur penuh.' });
    }
  }
  saveDB();
}

module.exports = { checkLimit, db, saveDB, cleanupExpiredPremium };
