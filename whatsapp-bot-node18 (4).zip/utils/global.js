/**
 * 🌐 Global Helper dan Variabel Bot
 */

global.botInfo = {
  name: 'Bot WhatsApp',
  creator: 'Deni Orlando',
  version: '18.20.8',
  website: 'https://orlando-digital.my.id',
  instagram: 'https://instagram.com/d_orlando1',
  whatsapp: 'https://wa.me/6283106346274'
};

global.runtimeCache = {
  connectedUsers: {},
  commandUsage: {},
  lastPing: null
};

// 🎛️ Variabel Konfigurasi Bot
global.namabot = 'Bot WhatsApp';
global.msg = {};
global.owner = ['6283106346274'];
global.packname = 'Orlando-Bot';
global.author = 'Deni Orlando';
global.foother = '© 2025 Orlando Digital';
global.website = 'https://orlando-digital.my.id';
global.namaowner = 'Deni Orlando';
global.emoji = '✅';
