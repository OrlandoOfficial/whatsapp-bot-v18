const moment = require('moment');

exports.formatUptime = (uptime) => {
  const duration = moment.duration(uptime, 'seconds');
  return duration.hours() + 'h ' + duration.minutes() + 'm ' + duration.seconds() + 's';
};

exports.sleep = (ms) => new Promise(resolve => setTimeout(resolve, ms));
