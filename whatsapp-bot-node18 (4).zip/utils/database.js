const { MongoClient } = require('mongodb');
const uri = process.env.MONGO_URI || 'mongodb://username:password@localhost:27017';
const dbName = process.env.MONGO_DB || 'whatsapp_bot';

let db = null;

async function connectDB() {
  if (db) return db;

  try {
    const client = new MongoClient(uri, {
      useNewUrlParser: true,
      useUnifiedTopology: true
    });

    await client.connect();
    db = client.db(dbName);
    console.log('✅ MongoDB connected');
    return db;
  } catch (error) {
    console.error('❌ MongoDB connection error:', error);
    process.exit(1);
  }
}

module.exports = connectDB;
