#!/bin/bash

echo "🔧 WhatsApp Bot Installer by Deni Orlando"
echo "----------------------------------------"

# 1. Update dan install dependencies (Ubuntu/Debian-based)
echo "📦 Updating system and installing Node.js v18.20.8..."
curl -fsSL https://deb.nodesource.com/setup_18.x | sudo -E bash -
sudo apt-get update -y
sudo apt-get install -y nodejs git unzip

# 2. Clone repo atau extract
echo "📁 Memastikan direktori whatsapp-bot tersedia..."
mkdir -p whatsapp-bot
cd whatsapp-bot

# 3. Copy .env.example ke .env jika belum ada
if [ ! -f .env ]; then
  cp .env.example .env
  echo "✅ File .env dibuat dari .env.example"
fi

# 4. Install node_modules
echo "📦 Menjalankan npm install..."
npm install

# 5. Jalankan bot
echo "🚀 Menjalankan bot..."
node index.js
