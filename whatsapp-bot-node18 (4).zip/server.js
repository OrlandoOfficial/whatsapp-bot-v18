const express = require('express');
const app = express();
const PORT = process.env.PORT || 3000;

app.get('/ping', (req, res) => {
  res.json({ status: '✅ Bot is active!', uptime: process.uptime() });
});

app.listen(PORT, () => {
  console.log(`🌐 Server monitoring aktif di http://localhost:${PORT}`);
});
