module.exports = async (sock, m, isPremium) => {
  if (!isPremium) return sock.sendMessage(m.key.remoteJid, { text: '🔒 Fitur ini khusus untuk pengguna Premium.' });

  await sock.sendMessage(m.key.remoteJid, {
    text: `🌟 Selamat datang pengguna Premium!
Nikmati akses penuh ke fitur eksklusif.`,
    footer: global.foother
  });
};
