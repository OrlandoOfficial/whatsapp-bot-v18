module.exports = async (sock, m, isOwner) => {
  if (!isOwner) return sock.sendMessage(m.key.remoteJid, { text: '🚫 Akses hanya untuk Owner!' });

  const reply = `👑 Menu Owner:
1. Restart Bot
2. Broadcast Pesan
3. Cek Pengguna Premium`;

  await sock.sendMessage(m.key.remoteJid, {
    text: reply,
    footer: global.foother
  });
};
