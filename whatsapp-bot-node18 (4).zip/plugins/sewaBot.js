module.exports = async (sock, jid) => {
  const text = `🛒 *Sewa Bot WhatsApp*

1. Paket Mingguan - Rp 20.000
2. Paket Bulanan - Rp 50.000
3. Paket Tahunan - Rp 300.000

Hubungi admin untuk aktivasi: https://wa.me/6281234567890`;

  await sock.sendMessage(jid, {
    text,
    footer: 'Orlando Digital | Sewa Bot\n© Deni Orlando'
  });
};
