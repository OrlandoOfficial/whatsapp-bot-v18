const fs = require('fs');
const dbPath = './auth/user-db.json';

if (!fs.existsSync(dbPath)) {
  fs.writeFileSync(dbPath, JSON.stringify({ banned: [], premium: [], usage: {}, requests: [] }, null, 2));
}

const db = JSON.parse(fs.readFileSync(dbPath));
function saveDB() {
  fs.writeFileSync(dbPath, JSON.stringify(db, null, 2));
}

module.exports = async (sock, m, sender) => {
  const number = sender.replace(/[^0-9]/g, '');
  const jid = m.key.remoteJid;

  if (db.premium.includes(sender)) {
    return sock.sendMessage(jid, { text: '✅ Kamu sudah menjadi pengguna Premium.' });
  }

  const exists = db.requests.find(req => req.number === number);
  if (exists) {
    return sock.sendMessage(jid, {
      text: `🕐 Permintaan Premium kamu sedang diproses Admin.`
    });
  }

  db.requests.push({ number, jid, status: 'pending' });
  saveDB();

  await sock.sendMessage(jid, {
    text: `📝 *Formulir Pembelian Premium*

Paket: 7 Hari
Harga: Rp. 5.000

Silakan transfer ke:
📱 *DANA: 0895433466090*
📍 Setelah transfer, kirim bukti ke Admin:
${require('../config').creator.whatsapp}`
  });

  // Kirim notifikasi ke admin
  const admin = require('../config').ownerNumber + '@s.whatsapp.net';
  await sock.sendMessage(admin, {
    text: `📥 *Permintaan Premium Baru*
Nomor: ${number}
Status: pending

Gunakan perintah:
#konfirmasi ${number}`
  });
};

// Fungsi konfirmasi oleh admin
module.exports.konfirmasi = function confirmPremium(number) {
  const expireDate = Date.now() + (7 * 24 * 60 * 60 * 1000);
  const id = number + '@s.whatsapp.net';
  if (!db.requests.some(req => req.number === number)) return false;

  db.premium.push(id);
  db.premium_expire[id] = expireDate;
  db.requests = db.requests.filter(req => req.number !== number);
  saveDB();
  return true;
};
