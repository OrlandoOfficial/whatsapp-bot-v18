const fs = require('fs');
const dbPath = './auth/user-db.json';

if (!fs.existsSync(dbPath)) {
  fs.writeFileSync(dbPath, JSON.stringify({ banned: [], premium: [] }, null, 2));
}

const db = JSON.parse(fs.readFileSync(dbPath));
function saveDB() {
  fs.writeFileSync(dbPath, JSON.stringify(db, null, 2));
}

module.exports = async (sock, m, command, args, sender, isOwner) => {
  const jid = m.key.remoteJid;

  if (!isOwner) {
    return sock.sendMessage(jid, { text: '🚫 Hanya Owner yang dapat menjalankan perintah ini.' });
  }

  const target = args[0]?.replace(/[^0-9]/g, '') + '@s.whatsapp.net';

  if (!args[0] || !target.includes('@s.whatsapp.net')) {
    return sock.sendMessage(jid, { text: '⚠️ Masukkan nomor yang valid. Contoh: #ban 628xxx' });
  }

  switch (command) {
    case 'ban':
      if (!db.banned.includes(target)) {
        db.banned.push(target);
        saveDB();
        sock.sendMessage(jid, { text: `🚫 Pengguna ${args[0]} telah diban.` });
      } else {
        sock.sendMessage(jid, { text: `⚠️ Pengguna ${args[0]} sudah diban.` });
      }
      break;

    case 'unban':
      db.banned = db.banned.filter(n => n !== target);
      saveDB();
      sock.sendMessage(jid, { text: `✅ Pengguna ${args[0]} telah diunban.` });
      break;

    case 'promote':
      if (!db.premium.includes(target)) {
        db.premium.push(target);
        saveDB();
        sock.sendMessage(jid, { text: `🌟 Pengguna ${args[0]} sekarang menjadi Premium.` });
      } else {
        sock.sendMessage(jid, { text: `⚠️ Pengguna ${args[0]} sudah Premium.` });
      }
      break;

    case 'kick':
      await sock.groupParticipantsUpdate(jid, [target], 'remove');
      sock.sendMessage(jid, { text: `👢 Pengguna ${args[0]} telah dikick.` });
      break;

    default:
      sock.sendMessage(jid, { text: '❓ Perintah tidak dikenal.' });
  }
};
