if (command === 'ping') {
  const uptime = process.uptime();
  await sock.sendMessage(sender, {
    text: `✅ Server Aktif\n⏱ Uptime: ${Math.floor(uptime)} detik`
  });
}
