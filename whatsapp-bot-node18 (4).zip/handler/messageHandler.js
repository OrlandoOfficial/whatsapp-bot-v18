const config = require('../config');
const { checkLimit, db } = require('../utils/limit');
const ownerHandler = require('../plugins/owner');
const premiumHandler = require('../plugins/premium');
const userManager = require('../plugins/userManager');
const beliPremium = require('../plugins/beliPremium');

module.exports = async (sock, m) => {
  const msg = m.messages[0];
  if (!msg?.message) return;

  const text = msg.message?.conversation || msg.message?.extendedTextMessage?.text;
  const sender = msg.key.remoteJid;
  const isOwner = config.ownerNumber.includes(sender.replace(/[^0-9]/g, ''));
  const isPremium = db.premium.includes(sender);
  const isBanned = db.banned.includes(sender);

  if (isBanned) {
    return sock.sendMessage(sender, {
      text: '🚫 Kamu telah diblokir dari penggunaan bot.'
    });
  }

  if (!text || !text.startsWith(config.prefix)) return;

  const body = text.slice(config.prefix.length).trim();
  const [command, ...args] = body.split(/\s+/);

  // Cek limit
  if (!checkLimit(sender, isPremium)) {
    return sock.sendMessage(sender, {
      text: `⛔ *Batas penggunaan harian kamu sudah habis!*

Untuk mengakses semua fitur tanpa batas:

🔥 *Upgrade ke Premium*
➤ Limit hingga 100x/hari
➤ Akses fitur eksklusif

💬 Chat Admin:
${config.creator.whatsapp}`
    });
  }

  switch (command.toLowerCase()) {
    case 'belipremium':
      await beliPremium(sock, m, sender);
      break;

    case 'konfirmasi':
      if (!isOwner) return sock.sendMessage(sender, { text: '❌ Hanya Admin yang dapat mengkonfirmasi.' });
      if (!args[0]) return sock.sendMessage(sender, { text: '⚠️ Masukkan nomor yang ingin dikonfirmasi.' });

      const success = beliPremium.konfirmasi(args[0].replace(/[^0-9]/g, ''));
      if (success) {
        const jidTarget = args[0].replace(/[^0-9]/g, '') + '@s.whatsapp.net';
        sock.sendMessage(jidTarget, { text: '🎉 Selamat! Kamu sekarang adalah pengguna Premium selama 7 hari.' });
        sock.sendMessage(sender, { text: `✅ Premium berhasil diaktifkan untuk ${args[0]}` });
      } else {
        sock.sendMessage(sender, { text: '❌ Nomor tidak ditemukan dalam daftar permintaan.' });
      }
      break;
    case 'menu':
      await sock.sendMessage(sender, {
        text: `✅ Menu Bot Aktif.
Gunakan prefix: ${config.prefix}
Powered by ${config.creator.name}`,
        footer: config.website
      });
      break;

    case 'ping':
      const uptime = process.uptime();
      await sock.sendMessage(sender, {
        text: `🏓 Pong!
Uptime: ${Math.floor(uptime)} detik`
      });
      break;

    case 'owner':
      await ownerHandler(sock, m, isOwner);
      break;

    case 'premium':
      await premiumHandler(sock, m, isPremium);
      break;

    case 'ban':
    case 'unban':
    case 'kick':
    case 'promote':
      await userManager(sock, m, command, args, sender, isOwner);
      break;

    default:
      await sock.sendMessage(sender, { text: '❓ Command tidak ditemukan.' });
  }
};
