# WhatsApp Bot - Multi Device (Baileys)

Bot WhatsApp Multi Device dibuat dengan Node.js & Baileys.
Mendukung:
- Menu interaktif (Website, Produk, Payment, Sewa)
- Koneksi WhatsApp Multi Device via QR Code
- Simulasi voice note, react status
- Konfigurasi dinamis via `config.js`
- Support VPS / Docker / Pterodactyl
- MongoDB ready
- Fitur `*ping` untuk test koneksi

## Cara Jalankan

```bash
npm install
node index.js
```

Atau gunakan Docker:

```bash
docker build -t whatsapp-bot .
docker run -it --name botwa -v $(pwd)/auth:/app/auth whatsapp-bot
```

## Creator
- 👤 Deni Orlando
- 📷 [Instagram](https://instagram.com/deni.orlando)
- 💬 [WhatsApp](https://wa.me/6281234567890)


## Runtime Environment
- Node.js v18.20.8.8.20.8

## 🔗 Pairing ke WhatsApp
QR Code akan muncul di console dan juga disimpan sebagai file: `assets/qr-code.png`

Scan QR tersebut dari aplikasi WhatsApp > Perangkat Tertaut > Tambah Perangkat.

### 📂 Multi QR Uploader
Selain qr-code.png, setiap QR baru akan disimpan juga ke `qr-code-[timestamp].png` secara otomatis.