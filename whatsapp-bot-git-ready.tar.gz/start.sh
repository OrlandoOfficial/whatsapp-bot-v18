#!/bin/bash
echo "📦 Installing dependencies..."
npm install

echo "🚀 Starting WhatsApp Bot..."
node index.js
